import { ProductDTO } from '../Components/Types/ProductDTO';
import { UserDTO } from '../Components/Types/UserDTO';
import { CartDTO } from '../Components/Types/CartDTO';
import { ProductFilterCriteria } from '../Components/Types/ProductFilterCriteria';
import { useEffect, useState } from 'react';
import { ProductAttributeDTO } from '../Components/Types/ProductAttributeDTO';
import { AttributeValueDTO } from '../Components/Types/AttributeValueDTO';
import * as FileSystem from 'expo-file-system';
import { Alert } from 'react-native';

export const BASE_URL = 'http://10.0.2.2:8080';

export function productImage(name: string): string {
    try {
        // Assuming that images are placed in the assets folder, you should reference them statically or store in appropriate path.
        return FileSystem.documentDirectory + `Images/${name.toLowerCase().replace(/\s+/g, '_').replace(/-/g, '_')}.png`;
    } catch (error: any) {
        console.log(error);
    }
    return "";
}

export const fetchProductById = async (id: number): Promise<ProductDTO> => {
    try {
        const response = await fetch(`${BASE_URL}/product/get/${id}`);

        if (!response.ok) {
            throw new Error(`Error fetching product with id ${id}: ${response.statusText}`);
        }

        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};

export const fetchAttributeValueById = async (id: number): Promise<AttributeValueDTO> => {
    try {
        const response = await fetch(`${BASE_URL}/attribute_value/get/${id}`);
        if (!response.ok) {
            throw new Error(`Error fetching attribute value with id ${id}: ${response.statusText}`);
        }
        const data: AttributeValueDTO = await response.json();
        return data;
    } catch (error: any) {
        console.log(error);
        throw new Error('Failed to fetch Attribute Value.');
    }
};

export const fetchUser = async (): Promise<UserDTO> => {
    const userId = await FileSystem.readAsStringAsync(FileSystem.documentDirectory + 'user-id.txt');
    if (!userId) {
        throw new Error('User ID is missing in local storage.');
    }
    try {
        const response = await fetch(`${BASE_URL}/user/get/${userId}`);
        if (!response.ok) {
            throw new Error('Could not get user.');
        }
        const user: UserDTO = await response.json();
        return user;
    } catch (error: any) {
        console.log(error.message);
        throw new Error('Failed to fetch user data.');
    }
};

export const fetchCart = async (): Promise<CartDTO> => {
    const userId = await FileSystem.readAsStringAsync(FileSystem.documentDirectory + 'user-id.txt');
    try {
        const response = await fetch(`${BASE_URL}/cart/get/${userId}`);
        const cart: CartDTO = await response.json();
        if (response.ok) {
            return cart;
        } else {
            throw new Error('Cart could not be retrieved.');
        }
    } catch (err: unknown) {
        console.log((err as Error).message);
        throw new Error('Failed to fetch cart data.');
    }
};

export const useFetchProducts = (
    productFilterCriteria: ProductFilterCriteria,
    sortBy: string
) => {
    const [productList, setProductList] = useState<ProductDTO[]>([]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await fetch(
                    `${BASE_URL}/product/filter?sortBy=${sortBy}`,
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(productFilterCriteria),
                    }
                );
                if (!response.ok) {
                    throw new Error('Could not get products.');
                }
                const data: ProductDTO[] = await response.json();
                setProductList(data);
            } catch (error: any) {
                console.log(error.message);
                Alert.alert('Error', 'Failed to fetch products');
            }
        };

        fetchProducts();
    }, [productFilterCriteria, sortBy]);

    return { productList };
};

export const useFetchProductAttributes = () => {
    const [productAttributeList, setProductAttributeList] = useState<ProductAttributeDTO[]>([]);

    useEffect(() => {
        const fetchProductAttributeList = async () => {
            try {
                const response = await fetch(
                    `${BASE_URL}/product_attribute/get`
                );
                if (!response.ok) {
                    throw new Error('Could not get product attributes.');
                }
                const data: ProductAttributeDTO[] = await response.json();
                setProductAttributeList(data);
            } catch (error: any) {
                console.log(error.message);
                Alert.alert('Error', 'Failed to fetch product attributes');
            }
        };

        fetchProductAttributeList();
    }, []);

    return { productAttributeList };
};
