import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import AccountInfoCard from './AccountInfoCard';
import {BASE_URL, fetchCart, fetchProductById, productImage} from './Utils/Utilities';
import { CartEntryDTO } from './Components/Types/CartEntryDTO';
import { ProductDTO } from './Components/Types/ProductDTO';
import { CartDTO } from './Components/Types/CartDTO';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import AsyncStorage from "@react-native-async-storage/async-storage";

const Order: React.FC<{ setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>> }> = ({ setIsLoggedIn }) => {
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();
    const [cart, setCart] = useState<CartDTO>({
        id: 0,
        cartEntryIdList: [],
        shopUserId: 0,
        totalPrice: 0,
    });
    const [entryList, setEntryList] = useState<CartEntryDTO[]>([]);
    const [productList, setProductList] = useState<ProductDTO[]>([]);

    useEffect(() => {
        const fetchEntries = async () => {
            try {
                const response = await fetch(`${BASE_URL}/cartEntry/get/${await AsyncStorage.getItem("cart-id")}`);
                if (!response.ok) {
                    throw new Error('Could not get cart entries.');
                }
                const data: CartEntryDTO[] = await response.json();

                const productsPromises = data.map((entry) => fetchProductById(entry.productId));
                const products = await Promise.all(productsPromises);
                setEntryList(data);
                setProductList(products);
            } catch (error: any) {
                console.log(error.message);
            }
        };
        fetchCart().then((fetchedCart) => {
            setCart(fetchedCart);
        });
        fetchEntries();
    }, []);

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Image
                    source={{ uri: 'https://www.kultofathena.com/wp-content/uploads/2021/03/weapons_page_title_bar.jpg' }}
                    style={styles.headerImage}
                />
                <Text style={styles.headerText}>Order</Text>
            </View>
            <ScrollView contentContainerStyle={styles.orderContent}>
                <View style={styles.orderEntriesDiv}>
                    {entryList.map((entry) => {
                        const product = productList.find((product) => product.id === entry.productId);
                        return (
                            <View key={entry.id} style={styles.orderPageEntryDiv}>
                                <TouchableOpacity
                                    onPress={() => {
                                        if (product?.id !== undefined) {
                                            navigation.navigate('Product', {productId: product.id});
                                        } else {
                                            console.error("Product ID is undefined");
                                        }
                                    }}
                                >
                                    <Image
                                        source={{ uri: product ? productImage(product.name) : '' }}
                                        style={styles.orderPageEntryImage}
                                    />
                                </TouchableOpacity>
                                <View style={styles.orderPageEntryDivText}>
                                    <Text>Name: {product ? product.name : 'Loading...'}</Text>
                                    <Text>Quantity: {entry.quantity}</Text>
                                    <Text>Total Price: ${entry.totalPricePerEntry}</Text>
                                </View>
                            </View>
                        );
                    })}
                </View>
                <View style={styles.orderPageOptions}>
                    <Text style={styles.totalText}>Total: ${cart.totalPrice}</Text>
                    <AccountInfoCard setIsLoggedIn={setIsLoggedIn} totalPrice={cart.totalPrice} />
                </View>
            </ScrollView>
        </View>
    );
};

export default Order;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1a1a1a',
    },
    header: {
        position: 'relative',
        maxHeight: 200,
        overflow: 'hidden',
    },
    headerImage: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
    },
    headerText: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -50 }, { translateY: -50 }],
        fontFamily: 'Metamorphous',
        color: 'white',
        fontSize: 24,
        textAlign: 'center',
    },
    orderContent: {
        marginTop: 20,
        flexWrap: 'wrap',
    },
    orderEntriesDiv: {
        flex: 1,
    },
    orderPageEntryDiv: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 110,
        width: '100%',
        color: 'white',
        margin: 10,
        borderColor: '#be9359',
        borderWidth: 1,
    },
    orderPageEntryImage: {
        width: 100,
        height: 100,
        resizeMode: 'contain',
    },
    orderPageEntryDivText: {
        marginLeft: 10,
        color: 'white',
    },
    orderPageOptions: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#a98351',
    },
    totalText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#a98351',
        textDecorationLine: 'underline',
    },
});
