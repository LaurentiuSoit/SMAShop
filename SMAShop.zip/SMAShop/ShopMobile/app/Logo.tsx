import React from 'react';
import { TouchableOpacity, Image, StyleSheet } from 'react-native';
import { NavigationProp, useNavigation } from '@react-navigation/native';
import { RootStackParamList } from "@/app/Components/Props/RootStackParamList";

const Logo: React.FC = () => {
    // Setting up navigation hook with proper type
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    return (
        <TouchableOpacity
            onPress={() => navigation.navigate('MainPage')} // Navigate to the MainPage when logo is pressed
            activeOpacity={0.7} // Optional: Control opacity when pressed
        >
            <Image
                source={require('../assets/images/koa_logo_w-300x75-1.png')} // Proper image path
                style={styles.logo}
                accessibilityLabel="Go to Home" // Accessibility improvement
            />
        </TouchableOpacity>
    );
};

export default Logo;

const styles = StyleSheet.create({
    logo: {
        width: 150,
        height: 50,
        resizeMode: 'contain',
    },
});
