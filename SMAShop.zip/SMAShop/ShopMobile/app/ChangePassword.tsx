import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Alert,
    Image,
    ScrollView,
} from 'react-native';
import {useRoute, RouteProp} from '@react-navigation/native';
import {MaterialIcons} from "@expo/vector-icons";
import {BASE_URL} from "@/app/Utils/Utilities";

type UserScreenRouteProp = RouteProp<{User: { userId: number }}, 'User'>;

const ChangePassword: React.FC = () => {
    const [newPassword, setNewPassword] = useState<string>('');
    const [confirmNewPassword, setConfirmNewPassword] = useState<string>('');
    const [changedPassword, setChangedPassword] = useState<boolean>(false);
    const route = useRoute<UserScreenRouteProp>();
    const { userId } = route.params;
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [passwordsMatch, setPasswordsMatch] = useState<boolean>(true);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const comparePasswords = (password1: string, password2: string) => {
        setPasswordsMatch(password1 === password2);
    };

    const handleNewPasswordChange = (value: string) => {
        setNewPassword(value);
        comparePasswords(value, confirmNewPassword);
    };

    const handleConfirmNewPasswordChange = (value: string) => {
        setConfirmNewPassword(value);
        comparePasswords(newPassword, value);
    };

    const handleSubmitChange = async () => {
        if (passwordsMatch) {
            try {
                const response = await fetch(
                    `${BASE_URL}/user/changePassword?id=${userId}&newPassword=${newPassword}`,
                    {
                        method: 'PUT',
                    }
                );
                if (response.ok) {
                    setChangedPassword(true);
                } else {
                    throw new Error('Could not change password.');
                }
            } catch (err: unknown) {
                console.log((err as Error).message);
                Alert.alert('Error', 'Could not change password. Please try again later.');
            }
        } else {
            Alert.alert('Error', 'Passwords do not match.');
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            {changedPassword ? (
                <Text style={styles.confirmText}>
                    Your password has been changed. You can now log in.
                </Text>
            ) : (
                <View style={styles.formContainer}>
                    <MaterialIcons name="lock" size={30} color="#a30015" style={styles.avatar} />
                    <Text style={styles.headerText}>Please enter your new password</Text>
                    <View style={styles.inputContainer}>
                        <TextInput
                            style={[styles.input, !passwordsMatch && styles.inputError]}
                            placeholder="New Password"
                            placeholderTextColor="#888"
                            secureTextEntry={!showPassword}
                            value={newPassword}
                            onChangeText={handleNewPasswordChange}
                        />
                        <TouchableOpacity onPress={handleClickShowPassword} style={styles.iconButton}>
                            <Text>{showPassword ? 'Hide' : 'Show'}</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput
                            style={[styles.input, !passwordsMatch && styles.inputError]}
                            placeholder="Confirm New Password"
                            placeholderTextColor="#888"
                            secureTextEntry={!showPassword}
                            value={confirmNewPassword}
                            onChangeText={handleConfirmNewPasswordChange}
                        />
                        <TouchableOpacity onPress={handleClickShowPassword} style={styles.iconButton}>
                            <Text>{showPassword ? 'Hide' : 'Show'}</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity style={styles.button} onPress={handleSubmitChange}>
                        <Text style={styles.buttonText}>CHANGE PASSWORD</Text>
                    </TouchableOpacity>
                </View>
            )}
        </ScrollView>
    );
};

export default ChangePassword;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
    },
    confirmText: {
        fontSize: 20,
        textAlign: 'center',
        color: 'green',
        marginTop: 50,
    },
    formContainer: {
        width: '100%',
        alignItems: 'center',
    },
    avatar: {
        width: 80,
        height: 80,
        marginBottom: 20,
    },
    headerText: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
        width: '100%',
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
    input: {
        flex: 1,
        padding: 10,
        fontSize: 16,
        color: '#000',
    },
    inputError: {
        borderBottomColor: 'red',
    },
    iconButton: {
        padding: 10,
    },
    button: {
        marginTop: 20,
        backgroundColor: '#a30015',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
        textAlign: 'center',
    },
});
