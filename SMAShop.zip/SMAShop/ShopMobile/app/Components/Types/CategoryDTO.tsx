export interface CategoryDTO {
    id: number;
    name: string;
    description: string;
}
