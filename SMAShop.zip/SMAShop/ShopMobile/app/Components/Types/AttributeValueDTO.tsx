export interface AttributeValueDTO {
    id: number;
    value: string;
}