export interface ShopUserCreationDTO {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    password: string;
};