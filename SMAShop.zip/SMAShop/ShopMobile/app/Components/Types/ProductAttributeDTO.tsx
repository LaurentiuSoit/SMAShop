export interface ProductAttributeDTO {
    id: number;
    name: string;
    attributeValueIdList: number[];
}