export interface AttributeDTO {
    name: string;
    value: string;
}