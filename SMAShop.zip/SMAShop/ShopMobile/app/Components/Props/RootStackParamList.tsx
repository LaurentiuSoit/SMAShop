export type RootStackParamList = {
    MainPage: undefined;
    SearchPage: { searchString: string };
    Category: { categoryId: number };
    Product: { productId: number };
    Account: undefined;
    SignUpForm: undefined;
    Cart: undefined;
    OrderHistory: undefined;
    Order: undefined;
    OrderConfirmation: undefined;
    ForgotPassword: undefined;
    ChangePassword: undefined;
};
