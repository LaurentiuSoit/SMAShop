import {ProductDTO} from "../Types/ProductDTO";

export interface ProductListProps {
    products: ProductDTO[];
}