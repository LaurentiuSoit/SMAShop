import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView, TouchableOpacity } from 'react-native';
import { Slider } from '@miblanchard/react-native-slider';
import { Checkbox } from 'react-native-paper';
import ProductList from './ProductList';
import {RouteProp, useRoute} from '@react-navigation/native';
import { ProductFilterCriteria } from './Components/Types/ProductFilterCriteria';
import { fetchAttributeValueById, useFetchProductAttributes, useFetchProducts } from './Utils/Utilities';

type SearchPageScreenRouteProp = RouteProp<{SearchPage: { searchString: string }}, 'SearchPage'>;


const SearchPage: React.FC = () => {
    const route = useRoute<SearchPageScreenRouteProp>();
    const searchString = route.params.searchString;
    const MINPRICE = 0;
    const MAXPRICE = 500;

    const [price, setPrice] = useState<number[]>([MINPRICE, MAXPRICE]);
    const [inStock, setInStock] = useState<boolean>(false);
    const [sortBy, setSortBy] = useState<string>('newest');
    const [attributeValues, setAttributeValues] = useState<Record<number, string>>({});
    const [productFilterCriteria, setProductFilterCriteria] = useState<ProductFilterCriteria>({
        minPrice: null,
        maxPrice: null,
        name: searchString,
        inStock: null,
        categoryId: null,
        attributeValueIds: []
    });

    const handleSortSelection = (value: string) => {
        setSortBy(value);
    };

    const handlePriceChange = (newValue: number | number[]) => {
        const [minPrice, maxPrice] = newValue as number[];

        setPrice([minPrice, maxPrice]);
        setProductFilterCriteria(prevState => ({
            ...prevState,
            minPrice: minPrice,
            maxPrice: maxPrice
        }));
    };

    const handleInStockChange = () => {
        const updatedInStock = !inStock;

        setInStock(updatedInStock);
        setProductFilterCriteria(prevState => ({
            ...prevState,
            inStock: updatedInStock
        }));
    };

    const handleValueCheckbox = (checked: boolean, id: number) => {
        setProductFilterCriteria(prevState => {
            if (checked) {
                return {
                    ...prevState,
                    attributeValueIds: [...prevState.attributeValueIds, id]
                };
            } else {
                return {
                    ...prevState,
                    attributeValueIds: prevState.attributeValueIds.filter(attributeId => attributeId !== id)
                };
            }
        });
    };

    const fetchAndSetAttributeValues = async (attributeValueIdList: number[]) => {
        const values = await Promise.all(
            attributeValueIdList.map(async (id) => {
                const attributeValue = await fetchAttributeValueById(id);
                return { id, value: attributeValue.value };
            })
        );
        setAttributeValues(prevValues => ({
            ...prevValues,
            ...Object.fromEntries(values.map(({ id, value }) => [id, value]))
        }));
    };

    useEffect(() => {
        setProductFilterCriteria(prevCriteria => ({
            ...prevCriteria,
            name: searchString,
        }));
    }, [searchString]);

    const { productList } = useFetchProducts(productFilterCriteria, sortBy);
    const { productAttributeList } = useFetchProductAttributes();

    useEffect(() => {
        if (productAttributeList) {
            productAttributeList.forEach(productAttribute => {
                fetchAndSetAttributeValues(productAttribute.attributeValueIdList);
            });
        }
    }, [productAttributeList]);

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerText}>Search results: "{searchString}"</Text>
            </View>
            <View style={styles.sortContainer}>
                <TextInput
                    style={styles.sortInput}
                    value={sortBy}
                    onChangeText={handleSortSelection}
                    placeholder="Sort By (e.g., newest, priceasc, pricedesc)"
                    placeholderTextColor="grey"
                />
            </View>
            <View style={styles.filterOptions}>
                <View style={styles.checkboxFilter}>
                    <Checkbox
                        status={inStock ? 'checked' : 'unchecked'}
                        onPress={handleInStockChange}
                        color="#be9359"
                    />
                    <Text style={styles.checkboxLabel}>Show only In Stock items</Text>
                </View>
                <View style={styles.priceFilter}>
                    <Text style={styles.priceFilterLabel}>Price</Text>
                    <Slider
                        value={price}
                        onValueChange={handlePriceChange}
                        minimumValue={MINPRICE}
                        maximumValue={MAXPRICE}
                        step={1}
                        trackClickable
                        minimumTrackTintColor="#be9359"
                        thumbTintColor="#be9359"
                    />
                </View>
                {productAttributeList.map(productAttribute => (
                    <View key={productAttribute.id} style={styles.filter}>
                        <Text style={styles.filterText}>{productAttribute.name}</Text>
                        {productAttribute.attributeValueIdList.map(attributeValueId => (
                            <View key={attributeValueId} style={styles.checkboxFilter}>
                                <Checkbox
                                    status={
                                        productFilterCriteria.attributeValueIds.includes(attributeValueId)
                                            ? 'checked'
                                            : 'unchecked'
                                    }
                                    onPress={() =>
                                        handleValueCheckbox(
                                            !productFilterCriteria.attributeValueIds.includes(attributeValueId),
                                            attributeValueId
                                        )
                                    }
                                    color="#be9359"
                                />
                                <Text style={styles.checkboxLabel}>
                                    {attributeValues[attributeValueId] || 'Loading...'}
                                </Text>
                            </View>
                        ))}
                    </View>
                ))}
            </View>
            <View style={styles.productList}>
                <ProductList products={productList} />
            </View>
        </ScrollView>
    );
};

export default SearchPage;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1a1a1a',
    },
    header: {
        padding: 20,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#be9359',
    },
    headerText: {
        fontFamily: 'Metamorphous',
        color: 'white',
        fontSize: 24,
    },
    sortContainer: {
        margin: 20,
    },
    sortInput: {
        backgroundColor: '#333333',
        color: 'white',
        padding: 10,
        borderRadius: 5,
    },
    filterOptions: {
        padding: 20,
    },
    checkboxFilter: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    checkboxLabel: {
        color: 'white',
        marginLeft: 8,
    },
    priceFilter: {
        marginVertical: 20,
    },
    priceFilterLabel: {
        color: 'white',
        marginBottom: 10,
    },
    filter: {
        marginVertical: 10,
    },
    filterText: {
        color: 'white',
        marginBottom: 5,
    },
    productList: {
        paddingBottom: 50,
    },
});
