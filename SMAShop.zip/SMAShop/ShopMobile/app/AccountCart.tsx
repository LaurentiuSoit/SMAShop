import React, {useEffect, useState} from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import { FontAwesome } from '@expo/vector-icons';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import AsyncStorage from "@react-native-async-storage/async-storage";

const AccountCart: React.FC<{ setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>> }> = ({ setIsLoggedIn }) => {
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();
    const [isLoggedIn, setIsLoggedInState] = useState<boolean>(false);

    useEffect(() => {
        const checkLoggedInStatus = async () => {
            const loggedIn = await AsyncStorage.getItem('logged-in');
            setIsLoggedInState(loggedIn === 'true');
        };
        checkLoggedInStatus();
    }, []);

    const handleLogout = async () => {
        Alert.alert('Logout', 'Are you sure you want to log out?', [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            {
                text: 'OK',
                onPress: async () => {
                    // Clear user state
                    await AsyncStorage.setItem('logged-in', 'false');
                    setIsLoggedIn(false);
                    await AsyncStorage.removeItem('user-id');
                    navigation.navigate('MainPage');
                    await AsyncStorage.removeItem('cart-id');
                },
            },
        ]);
    };

    return (
        <View style={styles.accountCartBox}>
            <View style={styles.accountDiv}>
                <TouchableOpacity onPress={() => navigation.navigate('Account')} style={styles.accountButton}>
                    <FontAwesome name="user" size={17} color="#be9359" style={styles.icon} />
                    <Text style={styles.accountButtonText}>My Account</Text>
                </TouchableOpacity>
                <View style={styles.accountMenu}>
                    <TouchableOpacity onPress={() => navigation.navigate('SignUpForm')}>
                        <Text style={styles.menuItem}>Dashboard</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => navigation.navigate('OrderHistory')}>
                        <Text style={styles.menuItem}>Orders</Text>
                    </TouchableOpacity>
                    {isLoggedIn && (
                        <TouchableOpacity onPress={handleLogout}>
                            <Text style={styles.menuItem}>Logout</Text>
                        </TouchableOpacity>
                    )}
                </View>
            </View>
            <TouchableOpacity onPress={() => navigation.navigate('Cart')} style={styles.cartButton}>
                <FontAwesome name="shopping-cart" size={17} color="#be9359" style={styles.icon} />
                <Text style={styles.cartButtonText}>Cart</Text>
            </TouchableOpacity>
        </View>
    );
};

export default AccountCart;

const styles = StyleSheet.create({
    accountCartBox: {
        flexDirection: 'row',
        alignSelf: 'center',
        flexWrap: 'wrap',
    },
    accountDiv: {
        flexDirection: 'column',
        alignItems: 'center',
        marginRight: 10,
    },
    accountButton: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 5,
    },
    accountButtonText: {
        color: '#be9359',
        fontSize: 17,
        fontFamily: 'Lato',
        textTransform: 'none',
    },
    accountMenu: {
        marginTop: 10,
        backgroundColor: '#1a1a1a',
        borderColor: '#be9359',
        borderWidth: 1,
        padding: 5,
        width: 200,
        alignItems: 'center',
    },
    menuItem: {
        color: '#ffffff',
        padding: 4,
    },
    cartButton: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 5,
    },
    cartButtonText: {
        color: '#be9359',
        fontSize: 17,
        fontFamily: 'Lato',
        textTransform: 'none',
    },
    icon: {
        marginRight: 3,
    },
});
