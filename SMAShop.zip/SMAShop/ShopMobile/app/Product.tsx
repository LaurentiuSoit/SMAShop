import React, { useEffect, useState } from 'react';
import { View, Text, Image, TextInput, Button, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import {RouteProp, useRoute} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ProductDTO } from './Components/Types/ProductDTO';
import { CategoryDTO } from './Components/Types/CategoryDTO';
import { AttributeDTO } from './Components/Types/AttributeDTO';
import {BASE_URL} from "@/app/Utils/Utilities";

type ProductScreenRouteProp = RouteProp<{Product: { productId: number }}, 'Product'>;

const Product: React.FC = () => {
    const route = useRoute<ProductScreenRouteProp>();
    const { productId } = route.params;
    const [quantity, setQuantity] = useState<number>(1);
    const [isInStock, setIsInStock] = useState<boolean>(false);
    const [added, setAdded] = useState<boolean>(false);
    const [product, setProduct] = useState<ProductDTO>({
        id: 0,
        name: "",
        price: 0,
        addedDate: "",
        availableQuantity: 0,
        categoryId: 0,
        description: "",
        validAttributeIdList: []
    });
    const [category, setCategory] = useState<CategoryDTO>({
        id: 0,
        name: '',
        description: ''
    });
    const [attributeList, setAttributeList] = useState<AttributeDTO[]>([]);
    const [error, setError] = useState<string | null>(null);

    const handleQtyChange = (value: string) => {
        setQuantity(Number(value));
    };

    const handleAddToCart = async () => {
        try {
            const cartId = await AsyncStorage.getItem('cart-id');
            if (!cartId) {
                throw new Error('Cart ID not found.');
            }
            const response = await fetch(`${BASE_URL}/cart/add?cartId=${cartId}&productId=${productId}&quantity=${quantity}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (!response.ok) {
                throw new Error(`Could not add product.`);
            }
            setAdded(true);
        } catch (error: any) {
            setError(error.message);
        }
    };

    useEffect(() => {
        const fetchProduct = async (productId: string | undefined) => {
            if (!productId) {
                return;
            }
            try {
                const response = await fetch(`${BASE_URL}/product/get/${productId}`);
                if (!response.ok) {
                    throw new Error('Could not get product.');
                }
                const data: ProductDTO = await response.json();
                setProduct(data);
                if (data.availableQuantity > 0) setIsInStock(true);
            } catch (error: any) {
                setError(error.message);
            }
        };
        fetchProduct(productId.toString());
    }, [productId]);

    useEffect(() => {
        const fetchCategory = async () => {
            if (!product.categoryId) {
                return;
            }
            try {
                const response = await fetch(`${BASE_URL}/category/get/${product.categoryId}`);
                if (!response.ok) {
                    throw new Error('Could not get category.');
                }
                const data: CategoryDTO = await response.json();
                setCategory(data);
            } catch (error: any) {
                setError(error.message);
            }
        };
        fetchCategory();
    }, [product.categoryId]);

    useEffect(() => {
        const fetchAttributes = async () => {
            if (!productId) {
                return;
            }
            try {
                const response = await fetch(`${BASE_URL}/product/getAttributes/${productId}`);
                if (!response.ok) {
                    throw new Error('Could not get product attributes.');
                }
                const data: AttributeDTO[] = await response.json();
                setAttributeList(data);
            } catch (error: any) {
                setError(error.message);
            }
        };
        fetchAttributes();
    }, [productId]);

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.breadcrumbs}>
                    Home » {category.name} » {product.name}
                </Text>
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productPrice}>${product.price}</Text>
            </View>
            <View style={styles.productContainer}>
                <Image
                    style={styles.productImage}
                    source={{ uri: `${BASE_URL}/public/Images/${product.name.toLowerCase().replaceAll(' ', '_').replaceAll('-', '_')}.png` }}
                />
                <View style={styles.productDetails}>
                    {added && <Text style={styles.successMessage}>Product Added to Cart</Text>}
                    <Text style={styles.stockStatus}>
                        {isInStock ? 'In Stock' : 'Out of Stock'}
                    </Text>
                    {isInStock && (
                        <View style={styles.quantityDiv}>
                            <Text style={styles.qtyLabel}>Qty:</Text>
                            <TextInput
                                style={styles.quantityInput}
                                keyboardType="numeric"
                                value={String(quantity)}
                                onChangeText={handleQtyChange}
                            />
                        </View>
                    )}
                    <TouchableOpacity
                        style={[styles.addToCartButton, !isInStock && styles.disabledButton]}
                        disabled={!isInStock}
                        onPress={handleAddToCart}
                    >
                        <Text style={styles.addToCartButtonText}>Add to Cart</Text>
                    </TouchableOpacity>
                    <View>
                        <Text style={styles.sectionTitle}>Description</Text>
                        <Text style={styles.description}>{product.description}</Text>
                    </View>
                    <View style={styles.specifications}>
                        <Text style={styles.sectionTitle}>Specifications</Text>
                        {attributeList.map(attribute => (
                            <Text key={attribute.name} style={styles.attributeText}>
                                {attribute.name} : {attribute.value}
                            </Text>
                        ))}
                    </View>
                </View>
            </View>
        </ScrollView>
    );
};

export default Product;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1a1a1a',
    },
    header: {
        padding: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#be9359',
    },
    breadcrumbs: {
        color: '#be9359',
        marginBottom: 10,
    },
    productName: {
        color: 'white',
        fontSize: 28,
        fontWeight: 'bold',
    },
    productPrice: {
        color: '#be9359',
        fontSize: 24,
    },
    productContainer: {
        flexDirection: 'row',
        padding: 20,
    },
    productImage: {
        width: 150,
        height: 250,
        marginRight: 20,
    },
    productDetails: {
        flex: 1,
    },
    successMessage: {
        color: 'green',
        fontSize: 16,
        marginBottom: 10,
    },
    stockStatus: {
        color: '#77a464',
        marginBottom: 10,
    },
    quantityDiv: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    qtyLabel: {
        color: 'white',
        marginRight: 10,
    },
    quantityInput: {
        width: 50,
        height: 40,
        borderColor: '#e1b65b',
        borderWidth: 1,
        color: 'white',
        textAlign: 'center',
    },
    addToCartButton: {
        backgroundColor: '#a30015',
        padding: 10,
        alignItems: 'center',
        marginBottom: 20,
    },
    disabledButton: {
        backgroundColor: '#5a1c1c',
    },
    addToCartButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },
    sectionTitle: {
        color: '#be9359',
        fontSize: 20,
        marginTop: 20,
        marginBottom: 10,
    },
    description: {
        color: 'white',
        marginBottom: 20,
    },
    specifications: {
        marginTop: 20,
    },
    attributeText: {
        color: 'white',
        marginBottom: 5,
    },
});
