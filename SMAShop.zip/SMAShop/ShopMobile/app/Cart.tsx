import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    TextInput,
    Alert,
    Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import {BASE_URL, fetchCart, fetchProductById, productImage} from './Utils/Utilities';
import { CartEntryDTO } from './Components/Types/CartEntryDTO';
import { ProductDTO } from './Components/Types/ProductDTO';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import {CartDTO} from "@/app/Components/Types/CartDTO";

const Cart: React.FC = () => {
    const [cart, setCart] = useState<CartDTO>({
        id: 0,
        cartEntryIdList: [],
        shopUserId: 0,
        totalPrice: 0,
    });
    const [entryList, setEntryList] = useState<CartEntryDTO[]>([]);
    const [productList, setProductList] = useState<ProductDTO[]>([]);
    const [error, setError] = useState<string | null>(null);
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    const handleQtyChange = async (newQuantity: number, entryId: number) => {
        try {
            const response = await fetch(
                `${BASE_URL}/cartEntry/update?entryId=${entryId}&cartId=${await AsyncStorage.getItem(
                    'cart-id'
                )}&newQuantity=${newQuantity}`,
                {
                    method: 'PUT',
                }
            );
            if (!response.ok) {
                throw new Error('Could not update quantity.');
            }
            const updatedEntries: CartEntryDTO[] = await response.json();
            setEntryList(updatedEntries);
        } catch (error: any) {
            setError(error.message);
        }
        fetchCart();
    };

    const handleRemove = async (entryId: number) => {
        try {
            const response = await fetch(
                `${BASE_URL}/cartEntry/delete?entryId=${entryId}&cartId=${await AsyncStorage.getItem(
                    'cart-id'
                )}`,
                {
                    method: 'DELETE',
                }
            );
            if (!response.ok) {
                throw new Error('Could not get cart entries.');
            }
            const updatedEntries: CartEntryDTO[] = await response.json();
            setEntryList(updatedEntries);
        } catch (error: any) {
            setError(error.message);
        }
    };

    const fetchEntries = async () => {
        try {
            const response = await fetch(
                `${BASE_URL}/cartEntry/get/${await AsyncStorage.getItem('cart-id')}`
            );
            if (!response.ok) {
                throw new Error('Could not get cart entries.');
            }
            const data: CartEntryDTO[] = await response.json();

            const productsPromises = data.map((entry) => fetchProductById(entry.productId));
            const products = await Promise.all(productsPromises);
            setEntryList(data);
            setProductList(products);
        } catch (error: any) {
            setError(error.message);
        }
    };

    useEffect(() => {
        fetchCart().then((fetchedCart) => {
            setCart(fetchedCart);
        });
        fetchEntries();
    }, []);

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.headerContainer}>
                <Image
                    style={styles.headerImage}
                    source={{
                        uri: 'https://www.kultofathena.com/wp-content/uploads/2021/03/weapons_page_title_bar.jpg',
                    }}
                />
                <Text style={styles.headerText}>Cart</Text>
            </View>
            <View style={styles.cartContent}>
                <View style={styles.cartEntriesDiv}>
                    {entryList.map((entry) => {
                        const product = productList.find((product) => product.id === entry.productId);
                        return (
                            <View key={entry.id} style={styles.cartPageEntryDiv}>
                                <TouchableOpacity onPress={() => {
                                    if (product?.id !== undefined) {
                                        navigation.navigate('Product', {productId: product.id});
                                    } else {
                                        console.error("Product ID is undefined");
                                    }
                                }}>
                                    <Image
                                        style={styles.cartPageEntryImage}
                                        source={{ uri: product ? productImage(product.name) : '' }}
                                        resizeMode="contain"
                                    />
                                </TouchableOpacity>
                                <View style={styles.cartPageEntryDivText}>
                                    <Text>Name: {product ? product.name : 'Loading...'}</Text>
                                    <Text>Quantity: {entry.quantity}</Text>
                                    <Text>Total Price: ${entry.totalPricePerEntry}</Text>
                                </View>
                                <View style={styles.cartPageQuantityDiv}>
                                    <Text>Qty</Text>
                                    <TextInput
                                        style={styles.quantitySelect}
                                        keyboardType="numeric"
                                        defaultValue={entry.quantity.toString()}
                                        onChangeText={(text) => handleQtyChange(Number(text), entry.id)}
                                    />
                                </View>
                                <TouchableOpacity onPress={() => handleRemove(entry.id)} style={styles.removeButton}>
                                    <Text style={styles.removeButtonText}>Remove</Text>
                                </TouchableOpacity>
                            </View>
                        );
                    })}
                </View>
                <View style={styles.cartPageOptions}>
                    <Text style={styles.totalText}>Total: ${cart.totalPrice}</Text>
                    <TouchableOpacity
                        style={styles.orderButton}
                        onPress={() => navigation.navigate('Order')}
                    >
                        <Text style={styles.orderButtonText}>Order</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
};

export default Cart;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#fff',
    },
    headerContainer: {
        position: 'relative',
        maxHeight: 200,
    },
    headerImage: {
        width: '100%',
        height: '100%',
    },
    headerText: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -50 }, { translateY: -50 }],
        fontSize: 24,
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    cartContent: {
        marginTop: 20,
        flexWrap: 'wrap',
    },
    cartEntriesDiv: {
        flex: 1,
    },
    cartPageEntryDiv: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        marginVertical: 10,
        backgroundColor: '#1a1a1a',
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#be9359',
    },
    cartPageEntryImage: {
        width: 100,
        height: 100,
        marginRight: 15,
    },
    cartPageEntryDivText: {
        flex: 1,
        color: 'white',
    },
    cartPageQuantityDiv: {
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 10,
    },
    quantitySelect: {
        width: 60,
        marginLeft: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#e1b65b',
        color: 'white',
    },
    removeButton: {
        backgroundColor: 'darkred',
        padding: 10,
        borderRadius: 5,
    },
    removeButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },
    cartPageOptions: {
        alignItems: 'center',
        marginTop: 20,
    },
    totalText: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        color: '#a98351',
    },
    orderButton: {
        backgroundColor: '#a30015',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    orderButtonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
    },
});
