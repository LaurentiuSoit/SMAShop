import React, { useEffect, useState } from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert} from 'react-native';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import { CategoryDTO } from './Components/Types/CategoryDTO';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import {BASE_URL} from "@/app/Utils/Utilities";

const NavBar: React.FC = () => {
    const [categoryList, setCategoryList] = useState<CategoryDTO[]>([]);
    const [error, setError] = useState<string | null>(null);
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await fetch(`${BASE_URL}/category/getAll`);
                if (!response.ok) {
                    throw new Error('Could not get categories.');
                }
                const data: CategoryDTO[] = await response.json();
                setCategoryList(data);
            } catch (error: any) {
                setError(error.message);
            }
        };
        fetchCategories();
    }, []);

    return (
        <ScrollView horizontal contentContainerStyle={styles.box}>
            {categoryList.map((category) => (
                <TouchableOpacity
                    key={category.id}
                    style={styles.categoryButton}
                    onPress={() => {
                        console.log(navigation.getState());
                        navigation.navigate('Category', {categoryId: category.id})
                    }}
                >
                    <Text style={styles.categoryButtonText}>{category.name}</Text>
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
};

export default NavBar;

const styles = StyleSheet.create({
    box: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        flexWrap: 'wrap',
    },
    categoryButton: {
        backgroundColor: '#1a1a1a',
        borderRadius: 5,
        padding: 10,
        margin: 5,
        alignItems: 'center',
    },
    categoryButtonText: {
        color: 'white',
        fontSize: 15,
        fontFamily: 'Lato',
    },
});
