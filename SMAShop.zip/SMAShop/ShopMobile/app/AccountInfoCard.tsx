import React, {useEffect, useState} from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    TextInput,
    Modal,
    Button as RNButton,
    Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import {BASE_URL, fetchUser} from './Utils/Utilities';
import {UserDTO} from './Components/Types/UserDTO';
import {ShopOrderDTO} from './Components/Types/ShopOrderDTO';
import {AddressDTO} from "@/app/Components/Types/AddressDTO";
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";

const AccountInfoCard: React.FC<{
    setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>>,
    isAccount?: boolean,
    totalPrice?: number,
}> = ({setIsLoggedIn, isAccount = false, totalPrice = 0}) => {
    const [user, setUser] = useState<UserDTO>({
        id: 0,
        email: '',
        firstName: '',
        lastName: '',
        phoneNumber: '',
        defaultBillingAddressId: 0,
        defaultDeliveryAddressId: 0,
    });
    const [updateUser, setUpdateUser] = useState<UserDTO>(user);
    const [billingAddress, setBillingAddress] = useState<AddressDTO>({
        id: 0,
        country: '',
        county: '',
        postalCode: 0,
        city: '',
        streetLine: '',
    });
    const [deliveryAddress, setDeliveryAddress] = useState<AddressDTO>({
        id: 0,
        country: '',
        county: '',
        postalCode: 0,
        city: '',
        streetLine: '',
    });
    const [addressList, setAddressList] = useState<AddressDTO[]>([]);
    const [newAddress, setNewAddress] = useState<AddressDTO>({
        id: 0,
        country: '',
        county: '',
        postalCode: 0,
        city: '',
        streetLine: '',
    });
    const [paymentType, setPaymentType] = useState<number>(0);
    const [loading, setLoading] = useState<boolean>(false);
    const [message, setMessage] = useState<string>('');
    const [hasError, setHasError] = useState<boolean>(false);
    const [isEditModalVisible, setIsEditModalVisible] = useState<boolean>(false);
    const [isAddAddressModalVisible, setIsAddAddressModalVisible] = useState<boolean>(false);
    const [isBillingAddressModalVisible, setIsBillingAddressModalVisible] = useState<boolean>(false);
    const [isDeliveryAddressModalVisible, setIsDeliveryAddressModalVisible] = useState<boolean>(false);
    const [isDeleteModalVisible, setIsDeleteModalVisible] = useState<boolean>(false);
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const fetchedUser = await fetchUser();
                setUser(fetchedUser);
                setUpdateUser(fetchedUser);
            } catch (error) {
                console.error(error);
            }
        };
        fetchUserDetails();
    }, []);

    const handleUpdateUserInfo = (key: keyof UserDTO, value: string) => {
        setUpdateUser((prev) => ({...prev, [key]: value}));
    };

    const handleSubmitUpdate = async () => {
        try {
            const response = await fetch(`${BASE_URL}/user/update/${user.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updateUser),
            });

            if (!response.ok) {
                throw new Error('Update failed.');
            }

            const newUser: UserDTO = await response.json();
            setUser(newUser);
            setIsEditModalVisible(false);
        } catch (err) {
            console.log('Error updating user:', err);
        }
    };

    const handleLogout = async () => {
        Alert.alert('Logout', 'Are you sure you want to log out?', [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            {
                text: 'OK',
                onPress: async () => {
                    await AsyncStorage.setItem('logged-in', 'false');
                    setIsLoggedIn(false);
                    navigation.navigate('MainPage');
                },
            },
        ]);
    };

    const handleAddAddressChange = (key: keyof AddressDTO, value: string) => {
        setNewAddress((prev) => ({...prev, [key]: value}));
    };

    const handleSubmitAddAddress = async () => {
        try {
            const response = await fetch(`${BASE_URL}/address/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newAddress),
            });

            if (!response.ok) {
                throw new Error('Could not add address.');
            }
        } catch (err) {
            console.log((err as Error).message);
        }
        setIsAddAddressModalVisible(false);
    };

    const handleOpenBillingAddressModal = async () => {
        try {
            const response = await fetch(`${BASE_URL}/address/getAll`);
            if (!response.ok) {
                throw new Error('Could not fetch addresses.');
            }
            const data: AddressDTO[] = await response.json();
            setAddressList(data);
        } catch (error: any) {
            console.log(error.message);
        }
        setIsBillingAddressModalVisible(true);
    };

    const handleOpenDeliveryAddressModal = async () => {
        try {
            const response = await fetch(`${BASE_URL}/address/getAll`);
            if (!response.ok) {
                throw new Error('Could not fetch addresses.');
            }
            const data: AddressDTO[] = await response.json();
            setAddressList(data);
        } catch (error: any) {
            console.log(error.message);
        }
        setIsDeliveryAddressModalVisible(true);
    };

    const handleSubmitBillingAddress = async (addressId: number) => {
        try {
            const response = await fetch(`${BASE_URL}/user/updateBillingAddress?userId=${user.id}&addressId=${addressId}`, {
                method: 'PUT',
            });
            if (!response.ok) {
                throw new Error('Could not update billing address.');
            }
            const newUser: UserDTO = await response.json();
            setUser(newUser);
        } catch (err: unknown) {
            console.log((err as Error).message);
        }
        setIsBillingAddressModalVisible(false);
    };

    const handleSubmitDeliveryAddress = async (addressId: number) => {
        try {
            const response = await fetch(`${BASE_URL}/user/updateDeliveryAddress?userId=${user.id}&addressId=${addressId}`, {
                method: 'PUT',
            });
            if (!response.ok) {
                throw new Error('Could not update delivery address.');
            }
            const newUser: UserDTO = await response.json();
            setUser(newUser);
        } catch (err: unknown) {
            console.log((err as Error).message);
        }
        setIsDeliveryAddressModalVisible(false);
    };

    const handleDeleteAccount = async () => {
        try {
            const response = await fetch(`${BASE_URL}/user/delete/${user.id}`, {
                method: 'DELETE',
            });
            if (!response.ok) {
                throw new Error('Could not delete user.');
            }
        } catch (error: any) {
            console.log(error.message);
        }
        await AsyncStorage.setItem('logged-in', 'false');
        setIsLoggedIn(false);
        navigation.navigate('MainPage');
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.accountCard}>
                <Text style={styles.accountCardText}>First Name: {user.firstName}</Text>
                <Text style={styles.accountCardText}>Last Name: {user.lastName}</Text>
                <Text style={styles.accountCardText}>Email: {user.email}</Text>
                <Text style={styles.accountCardText}>Phone Number: {user.phoneNumber}</Text>
                <Text style={styles.accountCardText}>
                    Billing
                    Address: {`${billingAddress.streetLine}, ${billingAddress.city}, ${billingAddress.postalCode}, ${billingAddress.county}, ${billingAddress.country}`}
                </Text>
                <Text style={styles.accountCardText}>
                    Delivery
                    Address: {`${deliveryAddress.streetLine}, ${deliveryAddress.city}, ${deliveryAddress.postalCode}, ${deliveryAddress.county}, ${deliveryAddress.country}`}
                </Text>

                <TouchableOpacity onPress={() => setIsEditModalVisible(true)} style={styles.editButton}>
                    <Text style={styles.editButtonText}>Edit Info</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => setIsAddAddressModalVisible(true)} style={styles.editButton}>
                    <Text style={styles.editButtonText}>Add Address</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={handleOpenBillingAddressModal} style={styles.editButton}>
                    <Text style={styles.editButtonText}>Select Billing Address</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={handleOpenDeliveryAddressModal} style={styles.editButton}>
                    <Text style={styles.editButtonText}>Select Delivery Address</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => setIsDeleteModalVisible(true)} style={styles.deleteButton}>
                    <Text style={styles.deleteButtonText}>Delete Account</Text>
                </TouchableOpacity>

                {/* Edit Info Modal */}
                <Modal
                    visible={isEditModalVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsEditModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Text style={styles.modalTitle}>Edit Information</Text>

                            <TextInput
                                style={styles.input}
                                placeholder="First Name"
                                value={updateUser.firstName}
                                onChangeText={(text) => handleUpdateUserInfo('firstName', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Last Name"
                                value={updateUser.lastName}
                                onChangeText={(text) => handleUpdateUserInfo('lastName', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Phone Number"
                                value={updateUser.phoneNumber}
                                onChangeText={(text) => handleUpdateUserInfo('phoneNumber', text)}
                                keyboardType="phone-pad"
                            />

                            <View style={styles.buttonContainer}>
                                <TouchableOpacity onPress={handleSubmitUpdate} style={styles.submitButton}>
                                    <Text style={styles.submitButtonText}>Save Changes</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setIsEditModalVisible(false)}
                                                  style={styles.cancelButton}>
                                    <Text style={styles.cancelButtonText}>Cancel</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>

                {/* Add Address Modal */}
                <Modal
                    visible={isAddAddressModalVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsAddAddressModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Text style={styles.modalTitle}>Add New Address</Text>

                            <TextInput
                                style={styles.input}
                                placeholder="Street Line"
                                value={newAddress.streetLine}
                                onChangeText={(text) => handleAddAddressChange('streetLine', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="City"
                                value={newAddress.city}
                                onChangeText={(text) => handleAddAddressChange('city', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="County"
                                value={newAddress.county}
                                onChangeText={(text) => handleAddAddressChange('county', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Postal Code"
                                value={newAddress.postalCode.toString()}
                                keyboardType="numeric"
                                onChangeText={(text) => handleAddAddressChange('postalCode', text)}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Country"
                                value={newAddress.country}
                                onChangeText={(text) => handleAddAddressChange('country', text)}
                            />

                            <View style={styles.buttonContainer}>
                                <TouchableOpacity onPress={handleSubmitAddAddress} style={styles.submitButton}>
                                    <Text style={styles.submitButtonText}>Add Address</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setIsAddAddressModalVisible(false)}
                                                  style={styles.cancelButton}>
                                    <Text style={styles.cancelButtonText}>Cancel</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>

                {/* Billing Address Modal */}
                <Modal
                    visible={isBillingAddressModalVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsBillingAddressModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Text style={styles.modalTitle}>Select Billing Address</Text>

                            {addressList.map((address) => (
                                <TouchableOpacity
                                    key={address.id}
                                    onPress={() => handleSubmitBillingAddress(address.id)}
                                    style={styles.addressOption}
                                >
                                    <Text style={styles.addressOptionText}>
                                        {`${address.streetLine}, ${address.city}, ${address.postalCode}, ${address.county}, ${address.country}`}
                                    </Text>
                                </TouchableOpacity>
                            ))}

                            <TouchableOpacity onPress={() => setIsBillingAddressModalVisible(false)}
                                              style={styles.cancelButton}>
                                <Text style={styles.cancelButtonText}>Cancel</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>

                {/* Delivery Address Modal */}
                <Modal
                    visible={isDeliveryAddressModalVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsDeliveryAddressModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Text style={styles.modalTitle}>Select Delivery Address</Text>

                            {addressList.map((address) => (
                                <TouchableOpacity
                                    key={address.id}
                                    onPress={() => handleSubmitDeliveryAddress(address.id)}
                                    style={styles.addressOption}
                                >
                                    <Text style={styles.addressOptionText}>
                                        {`${address.streetLine}, ${address.city}, ${address.postalCode}, ${address.county}, ${address.country}`}
                                    </Text>
                                </TouchableOpacity>
                            ))}

                            <TouchableOpacity onPress={() => setIsDeliveryAddressModalVisible(false)}
                                              style={styles.cancelButton}>
                                <Text style={styles.cancelButtonText}>Cancel</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>

                {/* Delete Account Modal */}
                <Modal
                    visible={isDeleteModalVisible}
                    transparent={true}
                    animationType="slide"
                    onRequestClose={() => setIsDeleteModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Text style={styles.modalTitle}>Delete Account</Text>
                            <Text style={styles.deleteWarningText}>Are you sure you want to delete your account? This
                                action cannot be undone.</Text>

                            <View style={styles.buttonContainer}>
                                <TouchableOpacity onPress={handleDeleteAccount} style={styles.deleteButton}>
                                    <Text style={styles.deleteButtonText}>Delete</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setIsDeleteModalVisible(false)}
                                                  style={styles.cancelButton}>
                                    <Text style={styles.cancelButtonText}>Cancel</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>
        </ScrollView>
    );
};

export default AccountInfoCard;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#fff',
    },
    accountCard: {
        backgroundColor: '#1a1a1a',
        padding: 20,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: 'dimgrey',
    },
    accountCardText: {
        color: 'white',
        fontSize: 16,
        marginBottom: 10,
    },
    editButton: {
        backgroundColor: '#be9359',
        padding: 10,
        borderRadius: 8,
        marginTop: 20,
    },
    editButtonText: {
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
    deleteButton: {
        backgroundColor: '#a30015',
        padding: 10,
        borderRadius: 8,
        marginTop: 20,
    },
    deleteButtonText: {
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        width: '80%',
        backgroundColor: '#fff',
        padding: 20,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 2},
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 5,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    input: {
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        marginBottom: 15,
        paddingVertical: 5,
        paddingHorizontal: 10,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 20,
    },
    submitButton: {
        backgroundColor: '#be9359',
        padding: 10,
        borderRadius: 5,
        width: '48%',
    },
    submitButtonText: {
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
    cancelButton: {
        backgroundColor: '#a30015',
        padding: 10,
        borderRadius: 5,
        width: '48%',
    },
    cancelButtonText: {
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
    addressOption: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
    addressOptionText: {
        color: '#000',
        fontSize: 16,
    },
    deleteWarningText: {
        color: '#a30015',
        fontSize: 16,
        textAlign: 'center',
        marginBottom: 20,
    },
});