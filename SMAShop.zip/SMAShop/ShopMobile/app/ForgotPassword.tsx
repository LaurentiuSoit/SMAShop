import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Alert,
    Image,
    ScrollView,
} from 'react-native';
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import {BASE_URL} from "@/app/Utils/Utilities";

const ForgotPassword: React.FC = () => {
    const [email, setEmail] = useState<string>('');
    const [sentEmail, setSentEmail] = useState<boolean>(false);

    const handleEmailChange = (value: string) => {
        setEmail(value);
    };

    const handleSubmitEmail = async () => {
        setSentEmail(true);

        try {
            const response = await fetch(
                `${BASE_URL}/user/forgotPassword?email=${email}`
            );
            if (!response.ok) {
                throw new Error('Could not send email.');
            }
        } catch (err: unknown) {
            console.log((err as Error).message);
            Alert.alert('Error', 'Could not send email. Please try again later.');
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            {sentEmail ? (
                <Text style={styles.confirmText}>Email for changing password has been sent!</Text>
            ) : (
                <View style={styles.formContainer}>
                    <MaterialIcons name="email" size={30} color="#a30015" style={styles.avatar} />
                    <Text style={styles.headerText}>Please enter your email</Text>
                    <View style={styles.inputContainer}>
                        <TextInput
                            style={styles.input}
                            placeholder="Email"
                            placeholderTextColor="#888"
                            keyboardType="email-address"
                            value={email}
                            onChangeText={handleEmailChange}
                        />
                    </View>
                    <TouchableOpacity style={styles.button} onPress={handleSubmitEmail}>
                        <Text style={styles.buttonText}>SEND EMAIL</Text>
                    </TouchableOpacity>
                </View>
            )}
        </ScrollView>
    );
};

export default ForgotPassword;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
    },
    confirmText: {
        fontSize: 20,
        textAlign: 'center',
        color: 'green',
        marginTop: 50,
    },
    formContainer: {
        width: '100%',
        alignItems: 'center',
    },
    avatar: {
        width: 80,
        height: 80,
        marginBottom: 20,
    },
    headerText: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    inputContainer: {
        width: '100%',
        marginBottom: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
    input: {
        padding: 10,
        fontSize: 16,
        color: '#000',
    },
    button: {
        marginTop: 20,
        backgroundColor: '#a30015',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
        textAlign: 'center',
    },
});
