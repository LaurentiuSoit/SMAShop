import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    Modal,
    Alert,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import {RouteProp, useRoute} from '@react-navigation/native';
import { Slider } from '@miblanchard/react-native-slider';
import ProductList from './ProductList';
import { CategoryDTO } from './Components/Types/CategoryDTO';
import { ProductFilterCriteria } from './Components/Types/ProductFilterCriteria';
import {BASE_URL, fetchAttributeValueById, useFetchProductAttributes, useFetchProducts} from './Utils/Utilities';

type CategoryScreenRouteProp = RouteProp<{Category: { categoryId: number }}, 'Category'>;

const Category: React.FC = () => {
    const MINPRICE = 0;
    const MAXPRICE = 500;
    const [price, setPrice] = useState<number[]>([MINPRICE, MAXPRICE]);
    const [inStock, setInStock] = useState<boolean>(false);
    const [category, setCategory] = useState<CategoryDTO>({
        id: 0,
        name: '',
        description: '',
    });
    const [sortBy, setSortBy] = useState<string>('newest');
    const [attributeValues, setAttributeValues] = useState<Record<number, string>>({});
    const route = useRoute<CategoryScreenRouteProp>();
    const categoryId  = route.params.categoryId.toString();

    const [productFilterCriteria, setProductFilterCriteria] = useState<ProductFilterCriteria>({
        minPrice: null,
        maxPrice: null,
        name: null,
        inStock: null,
        categoryId: categoryId || null,
        attributeValueIds: [],
    });

    const marks = [
        {
            value: MINPRICE,
            label: `${MINPRICE}`,
        },
        {
            value: MAXPRICE,
            label: `${MAXPRICE}`,
        },
    ];

    const handlePriceChange = (newValue: number[]) => {
        const [minPrice, maxPrice] = newValue;
        setPrice([minPrice, maxPrice]);

        setProductFilterCriteria((prevState) => ({
            ...prevState,
            minPrice: minPrice,
            maxPrice: maxPrice,
        }));
    };

    const handleInStockChange = (updatedInStock: boolean) => {
        setInStock(updatedInStock);
        setProductFilterCriteria((prevState) => ({
            ...prevState,
            inStock: updatedInStock,
        }));
    };

    const handleValueCheckbox = (id: number, checked: boolean) => {
        setProductFilterCriteria((prevState) => {
            if (checked) {
                return {
                    ...prevState,
                    attributeValueIds: [...prevState.attributeValueIds, id],
                };
            } else {
                return {
                    ...prevState,
                    attributeValueIds: prevState.attributeValueIds.filter((attributeId) => attributeId !== id),
                };
            }
        });
    };

    const fetchAndSetAttributeValues = async (attributeValueIdList: number[]) => {
        const values = await Promise.all(
            attributeValueIdList.map(async (id) => {
                const attributeValue = await fetchAttributeValueById(id);
                return { id, value: attributeValue.value };
            })
        );
        setAttributeValues((prevValues) => ({
            ...prevValues,
            ...Object.fromEntries(values.map(({ id, value }) => [id, value])),
        }));
    };

    useEffect(() => {
        setProductFilterCriteria((prevCriteria) => ({
            ...prevCriteria,
            categoryId: categoryId || null,
        }));
    }, [categoryId]);

    useEffect(() => {
        const fetchCategory = async () => {
            if (!categoryId) {
                return;
            }
            try {
                const response = await fetch(`${BASE_URL}/category/get/${categoryId}`);
                if (!response.ok) {
                    throw new Error('Could not get category.');
                }
                const data: CategoryDTO = await response.json();
                setCategory(data);
            } catch (error: any) {
                console.log(error.message);
            }
        };
        fetchCategory();
    }, [categoryId]);

    const { productList } = useFetchProducts(productFilterCriteria, sortBy);
    const { productAttributeList } = useFetchProductAttributes();

    useEffect(() => {
        if (productAttributeList) {
            productAttributeList.forEach((productAttribute) => {
                fetchAndSetAttributeValues(productAttribute.attributeValueIdList);
            });
        }
    }, [productAttributeList]);

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.headerContainer}>
                <Image
                    style={styles.headerImage}
                    source={{
                        uri: 'https://www.kultofathena.com/wp-content/uploads/2021/03/weapons_page_title_bar.jpg',
                    }}
                />
                <Text style={styles.headerText}>{category.name}</Text>
            </View>
            <View style={styles.formControl}>
                <Picker
                    selectedValue={sortBy}
                    onValueChange={(itemValue) => setSortBy(itemValue)}
                    style={styles.select}
                >
                    <Picker.Item label="Sort By Newest" value="newest" />
                    <Picker.Item label="Sort By Price Ascending" value="priceasc" />
                    <Picker.Item label="Sort By Price Descending" value="pricedesc" />
                </Picker>
            </View>
            <View style={styles.mainPageContent}>
                <View style={styles.filterOptions}>
                    <TouchableOpacity
                        style={styles.checkboxFilter}
                        onPress={() => handleInStockChange(!inStock)}
                    >
                        <Text style={styles.filterLabel}>{inStock ? '✓' : '⬜'} Show only In Stock items</Text>
                    </TouchableOpacity>
                    <View style={styles.priceFilter}>
                        <Text style={styles.filterLabel}>Price</Text>
                        <Slider
                            value={price}
                            onValueChange={(newValue) => handlePriceChange(newValue as number[])}
                            minimumValue={MINPRICE}
                            maximumValue={MAXPRICE}
                            step={1}
                            minimumTrackTintColor="#be9359"
                            maximumTrackTintColor="#000000"
                        />
                    </View>
                    {productAttributeList.map((productAttribute) => (
                        <View key={productAttribute.id} style={styles.filterSection}>
                            <Text style={styles.filterLabel}>{productAttribute.name}</Text>
                            {productAttribute.attributeValueIdList.map((attributeValueId) => (
                                <TouchableOpacity
                                    key={attributeValueId}
                                    style={styles.checkboxFilter}
                                    onPress={() =>
                                        handleValueCheckbox(
                                            attributeValueId,
                                            !productFilterCriteria.attributeValueIds.includes(attributeValueId)
                                        )
                                    }
                                >
                                    <Text style={styles.filterLabel}>
                                        {productFilterCriteria.attributeValueIds.includes(attributeValueId) ? '✓' : '⬜'}{' '}
                                        {attributeValues[attributeValueId] || 'Loading...'}
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    ))}
                </View>
                <View style={styles.productList}>
                    <ProductList products={productList} />
                </View>
            </View>
        </ScrollView>
    );
};

export default Category;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#fff',
    },
    headerContainer: {
        position: 'relative',
        maxHeight: 200,
    },
    headerImage: {
        width: '100%',
        height: '100%',
    },
    headerText: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -50 }, { translateY: -50 }],
        fontSize: 24,
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    formControl: {
        marginVertical: 20,
    },
    select: {
        height: 50,
        borderWidth: 1,
        borderColor: '#be9359',
        borderRadius: 5,
        marginBottom: 15,
    },
    mainPageContent: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    filterOptions: {
        flex: 1,
        marginRight: 10,
    },
    filterLabel: {
        fontSize: 16,
        marginBottom: 5,
    },
    checkboxFilter: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 5,
    },
    priceFilter: {
        marginBottom: 20,
    },
    filterSection: {
        marginVertical: 10,
    },
    productList: {
        flex: 3,
    },
});
