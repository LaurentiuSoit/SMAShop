import React, {useEffect, useState} from 'react';
import {Button, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {NavigationContainer, NavigationProp} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import NavBar from './NavBar'; // This component needs to be converted to a React Native component
import Logo from './Logo'; // This component needs to be adapted to work in React Native
import SearchBar from './SearchBar'; // Similarly, adapt this to use React Native elements
import AccountCart from './AccountCart'; // Convert this to use React Native components
import MainPage from './MainPage'; // Will serve as one of the screens
import Category from './Category';
import SignUpForm from './SignUpForm';
import Cart from './Cart';
import Account from './Account';
import Product from './Product';
import Order from './Order';
import OrderConfirmation from './OrderConfirmation';
import ForgotPassword from './ForgotPassword';
import ChangePassword from './ChangePassword';
import SearchPage from './SearchPage';
import OrderHistory from './OrderHistory';
import {useNavigation} from "expo-router";
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import {BASE_URL, productImage} from "@/app/Utils/Utilities";
import {NativeStackScreenProps} from "@react-navigation/native-stack";
import {GestureHandlerRootView} from "react-native-gesture-handler";
import AsyncStorage from "@react-native-async-storage/async-storage";

type AccountScreenProps = NativeStackScreenProps<RootStackParamList, 'Account'>;
type SignUpFormScreenProps = NativeStackScreenProps<RootStackParamList, 'SignUpForm'>;
type OrderScreenProps = NativeStackScreenProps<RootStackParamList, 'Order'>;

export default function Index() {
    const Stack = createStackNavigator<RootStackParamList>();
    const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
    const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
    const [entryList, setEntryList] = useState<any[]>([]);
    const [productList, setProductList] = useState<any[]>([]);
    const [error, setError] = useState<string | null>(null);
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    const handleMyCartClick = () => {
        openDrawer();
        navigation.navigate('Cart');
    };

    const fetchProductById = async (id: number) => {
        try {
            const response = await fetch(`${BASE_URL}/product/get/${id}`);
            if (!response.ok) {
                throw new Error(`Error fetching product with id ${id}: ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error(error);
            throw error;
        }
    };

    const openDrawer = () => {
        setIsDrawerOpen(!isDrawerOpen);
        if (!isDrawerOpen) {
            const fetchEntries = async () => {
                try {
                    const response = await fetch(`${BASE_URL}/cartEntry/get/${await AsyncStorage.getItem('cart-id')}`);
                    if (!response.ok) {
                        throw new Error('Could not get cart entries.');
                    }
                    const data = await response.json();
                    const productsPromises = data.map((entry: any) => fetchProductById(entry.productId));
                    const products = await Promise.all(productsPromises);
                    setEntryList(data);
                    setProductList(products);
                } catch (error: any) {
                    setError(error.message);
                }
            };
            fetchEntries();
        }
    };

    const CheckLoggedIn = async () => {
        setIsLoggedIn(await AsyncStorage.getItem('logged-in') === 'true');
    }

    useEffect(() => {
        CheckLoggedIn();
    }, []);
  return (
      <GestureHandlerRootView style={{ flex: 1 }}>
          <Stack.Navigator initialRouteName="MainPage" >
              <Stack.Screen name="MainPage" component={MainPage} />
              <Stack.Screen name="SearchPage" component={SearchPage} />
              <Stack.Screen name="Category" component={Category} />
              <Stack.Screen name="Product" component={Product} />
              <Stack.Screen name="Account" component={(props:AccountScreenProps) => <Account {...props} setIsLoggedIn={setIsLoggedIn} />}  />
              <Stack.Screen name="SignUpForm" component={(props:SignUpFormScreenProps) => <SignUpForm {...props} setIsLoggedIn={setIsLoggedIn} />} />
              <Stack.Screen name="Cart" component={Cart} />
              <Stack.Screen name="OrderHistory" component={OrderHistory} />
              <Stack.Screen name="Order" component={(props:OrderScreenProps) => <Order {...props} setIsLoggedIn={setIsLoggedIn} />} />
              <Stack.Screen name="OrderConfirmation" component={OrderConfirmation} />
              <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
              <Stack.Screen name="ChangePassword" component={ChangePassword} />
          </Stack.Navigator>
          <View style={styles.app}>
              <View style={styles.header}>
                  <View style={styles.colorBar}>
                      <Text style={styles.colorBarText}>
                          The largest collection of swords, weapons and more from the Bronze Age to World War II
                      </Text>
                  </View>
                  <View style={styles.headerWrapper}>
                      <View style={styles.topElements}>
                          <Logo />
                          <View style={styles.searchBarWrapper}>
                              <SearchBar />
                          </View>
                          <AccountCart setIsLoggedIn={setIsLoggedIn} />
                      </View>
                      <NavBar />
                  </View>
              </View>
              <TouchableOpacity
                  style={[styles.floatingCart, isDrawerOpen ? styles.floatingCartOpen : null]}
                  onPress={openDrawer}
              >
                  <Text style={styles.cartIcon}>🛒</Text>
              </TouchableOpacity>
              {isDrawerOpen && (
                  <View style={styles.drawerBox}>
                      <View style={styles.drawerBoxHeader}>
                          <Text style={styles.drawerBoxCart}>🛒</Text>
                          <Text style={styles.drawerTitle}>Your Cart</Text>
                      </View>
                      <ScrollView style={styles.entryContainer}>
                          {entryList.map((entry) => {
                              const product = productList.find((product) => product.id === entry.productId);
                              return (
                                  <View key={entry.id} style={styles.entryDiv}>
                                      <TouchableOpacity onPress={() => navigation.navigate('Product', { productId: product ? product.id : '' })}>
                                          <Image
                                              style={styles.entryImage}
                                              source={{ uri: product ? productImage(product.name) : '' }}
                                          />
                                      </TouchableOpacity>
                                      <View style={styles.entryDivText}>
                                          <Text>Name: {product ? product.name : 'Loading...'}</Text>
                                          <Text>Quantity: {entry.quantity}</Text>
                                          <Text>Total Price: ${entry.totalPricePerEntry}</Text>
                                      </View>
                                  </View>
                              );
                          })}
                      </ScrollView>
                      <Button title="Go To Cart" onPress={handleMyCartClick} />
                  </View>
              )}
          </View>
      </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
    app: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        backgroundColor: '#000000',
        minHeight: 100,
        paddingBottom: 10,
    },
    colorBar: {
        backgroundColor: '#be9359',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
    },
    colorBarText: {
        color: '#ffffff',
        fontWeight: 'bold',
    },
    headerWrapper: {
        alignItems: 'center',
    },
    topElements: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        marginVertical: 10,
    },
    searchBarWrapper: {
        maxWidth: 500,
        width: '80%',
    },
    floatingCart: {
        backgroundColor: '#a30015',
        position: 'absolute',
        bottom: 30,
        right: 30,
        padding: 15,
        borderRadius: 30,
    },
    floatingCartOpen: {
        right: 330,
    },
    cartIcon: {
        color: '#ffffff',
        fontSize: 20,
    },
    drawerBox: {
        position: 'absolute',
        right: 0,
        top: 0,
        height: '100%',
        width: 350,
        backgroundColor: '#070707',
        padding: 10,
    },
    drawerBoxHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 10,
    },
    drawerBoxCart: {
        fontSize: 20,
        paddingRight: 5,
        color: '#be9359',
    },
    drawerTitle: {
        fontSize: 18,
        color: '#be9359',
    },
    entryContainer: {
        maxHeight: '80%',
    },
    entryDiv: {
        flexDirection: 'row',
        marginVertical: 5,
        borderColor: '#be9359',
        borderWidth: 1,
        padding: 5,
    },
    entryImage: {
        width: 80,
        height: 80,
        marginRight: 10,
    },
    entryDivText: {
        justifyContent: 'center',
    },
});

