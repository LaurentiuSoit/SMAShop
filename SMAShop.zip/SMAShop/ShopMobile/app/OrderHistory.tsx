import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ShopOrderDTO } from './Components/Types/ShopOrderDTO';
import { AddressDTO } from './Components/Types/AddressDTO';
import {BASE_URL} from "@/app/Utils/Utilities";

const OrderHistory: React.FC = () => {
    const [addressList, setAddressList] = useState<AddressDTO[]>([]);
    const [orderList, setOrderList] = useState<ShopOrderDTO[]>([]);

    useEffect(() => {
        const fetchAddresses = async () => {
            try {
                const response = await fetch("${BASE_URL}/address/getAll");
                if (!response.ok) {
                    throw new Error("Could not fetch addresses.");
                }
                const data: AddressDTO[] = await response.json();
                setAddressList(data);
            } catch (error: any) {
                console.log(error.message);
            }
        };
        const fetchOrderHistory = async () => {
            try {
                const userId = await AsyncStorage.getItem("user-id");
                if (!userId) {
                    throw new Error("User ID not found.");
                }
                const response = await fetch(`${BASE_URL}/order/get/${userId}`);
                if (!response.ok) {
                    throw new Error('Could not get order history.');
                }
                const data: ShopOrderDTO[] = await response.json();
                setOrderList(data);
            } catch (error: any) {
                console.log(error.message);
            }
        };
        fetchAddresses();
        fetchOrderHistory();
    }, []);

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerText}>Order History</Text>
            </View>
            <ScrollView contentContainerStyle={styles.orderHistoryDiv}>
                {orderList.map(order => {
                    const deliveryAddress = addressList.find(address => address.id === order.deliveryAddressId);
                    const billingAddress = addressList.find(address => address.id === order.invoiceAddressId);
                    return (
                        <View key={order.id} style={styles.orderHistoryEntryDiv}>
                            <Text style={styles.orderText}>Total Price: ${order.totalPrice}</Text>
                            <Text style={styles.orderText}>Payment Type: {order.paymentType}</Text>
                            <Text style={styles.orderText}>Delivery Address: {deliveryAddress ? `${deliveryAddress.streetLine}, ${deliveryAddress.city}, ${deliveryAddress.postalCode}, ${deliveryAddress.county}, ${deliveryAddress.country}` : "Loading..."}</Text>
                            <Text style={styles.orderText}>Billing Address: {billingAddress ? `${billingAddress.streetLine}, ${billingAddress.city}, ${billingAddress.postalCode}, ${billingAddress.county}, ${billingAddress.country}` : "Loading..."}</Text>
                            <Text style={styles.orderText}>Order Date: {order.orderDate.toLocaleDateString()}</Text>
                        </View>
                    );
                })}
            </ScrollView>
        </View>
    );
};

export default OrderHistory;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1a1a1a',
    },
    header: {
        padding: 20,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#be9359',
    },
    headerText: {
        fontFamily: 'Metamorphous',
        color: 'white',
        fontSize: 24,
        textAlign: 'center',
    },
    orderHistoryDiv: {
        padding: 20,
    },
    orderHistoryEntryDiv: {
        marginBottom: 20,
        padding: 15,
        borderWidth: 1,
        borderColor: '#be9359',
        backgroundColor: '#2a2a2a',
    },
    orderText: {
        color: 'white',
        marginBottom: 5,
    },
});
