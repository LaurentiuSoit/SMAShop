import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Switch
} from 'react-native';
import ProductList from './ProductList';
import { useFetchProductAttributes, useFetchProducts, fetchAttributeValueById } from './Utils/Utilities';
import { AttributeValueDTO } from './Components/Types/AttributeValueDTO';
import {Picker} from "@react-native-picker/picker";
import {Slider} from "@miblanchard/react-native-slider";
import {ProductFilterCriteria} from "@/app/Components/Types/ProductFilterCriteria";

const MainPage: React.FC = () => {
    const MINPRICE = 0;
    const MAXPRICE = 500;
    const [price, setPrice] = useState<number[]>([MINPRICE, MAXPRICE]);
    const [inStock, setInStock] = useState<boolean>(false);
    const [sortBy, setSortBy] = useState<string>('newest');
    const [attributeValues, setAttributeValues] = useState<Record<number, string>>({});
    const [productFilterCriteria, setProductFilterCriteria] = useState<ProductFilterCriteria>({
        minPrice: null,
        maxPrice: null,
        name: null,
        inStock: null,
        categoryId: null,
        attributeValueIds: [],
    });

    const handleSortSelection = (value: string) => {
        setSortBy(value);
    };

    const handlePriceChange = (newValue: number[]) => {
        const [minPrice, maxPrice] = newValue;
        setPrice([minPrice, maxPrice]);
        setProductFilterCriteria((prevState) => ({
            ...prevState,
            minPrice: minPrice,
            maxPrice: maxPrice,
        }));
    };

    const handleInStockChange = (value: boolean) => {
        setInStock(value);
        setProductFilterCriteria((prevState) => ({
            ...prevState,
            inStock: value,
        }));
    };

    const handleValueCheckbox = (id: number, checked: boolean) => {
        setProductFilterCriteria((prevState) => {
            if (checked) {
                return {
                    ...prevState,
                    attributeValueIds: [...prevState.attributeValueIds, id],
                };
            } else {
                return {
                    ...prevState,
                    attributeValueIds: prevState.attributeValueIds.filter((attributeId) => attributeId !== id),
                };
            }
        });
    };

    const fetchAndSetAttributeValues = async (attributeValueIdList: number[]) => {
        const values = await Promise.all(
            attributeValueIdList.map(async (id) => {
                const attributeValue = await fetchAttributeValueById(id);
                return { id, value: attributeValue.value };
            })
        );
        setAttributeValues((prevValues) => ({
            ...prevValues,
            ...Object.fromEntries(values.map(({ id, value }) => [id, value])),
        }));
    };

    const { productList } = useFetchProducts(productFilterCriteria, sortBy);
    const { productAttributeList } = useFetchProductAttributes();

    useEffect(() => {
        if (productAttributeList) {
            productAttributeList.forEach((productAttribute) => {
                fetchAndSetAttributeValues(productAttribute.attributeValueIdList);
            });
        }
    }, [productAttributeList]);

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.formControl}>
                <Picker
                    selectedValue={sortBy}
                    style={styles.picker}
                    onValueChange={(itemValue) => handleSortSelection(itemValue)}
                >
                    <Picker.Item label="Sort By Newest" value="newest" />
                    <Picker.Item label="Sort By Price Ascending" value="priceasc" />
                    <Picker.Item label="Sort By Price Descending" value="pricedesc" />
                </Picker>
            </View>
            <View style={styles.mainPageContent}>
                <View style={styles.filterOptions}>
                    <View style={styles.checkboxFilter}>
                        <Text>Show only In Stock items</Text>
                        <Switch value={inStock} onValueChange={handleInStockChange} />
                    </View>
                    <View style={styles.priceFilter}>
                        <Text style={styles.filterText}>Price</Text>
                        <Slider
                            minimumValue={MINPRICE}
                            maximumValue={MAXPRICE}
                            step={1}
                            value={price}
                            onValueChange={(value) => handlePriceChange(value)}
                        />
                    </View>
                    {productAttributeList.map((productAttribute) => (
                        <View key={productAttribute.id} style={styles.filterSection}>
                            <Text style={styles.filterTitle}>{productAttribute.name}</Text>
                            {productAttribute.attributeValueIdList.map((attributeValueId) => (
                                <View key={attributeValueId} style={styles.checkboxFilter}>
                                    <Text>{attributeValues[attributeValueId] || 'Loading...'}</Text>
                                    <Switch
                                        onValueChange={(checked) => handleValueCheckbox(attributeValueId, checked)}
                                        value={productFilterCriteria.attributeValueIds.includes(attributeValueId)}
                                    />
                                </View>
                            ))}
                        </View>
                    ))}
                </View>
                <View style={styles.productList}>
                    <ProductList products={productList} />
                </View>
            </View>
        </ScrollView>
    );
};

export default MainPage;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#fff',
    },
    formControl: {
        marginBottom: 15,
    },
    picker: {
        height: 50,
        width: '100%',
    },
    mainPageContent: {
        flexDirection: 'row',
    },
    filterOptions: {
        flex: 1,
        marginRight: 10,
    },
    productList: {
        flex: 3.5,
    },
    checkboxFilter: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    priceFilter: {
        marginBottom: 20,
    },
    filterText: {
        fontSize: 16,
        marginBottom: 5,
    },
    filterSection: {
        marginBottom: 15,
    },
    filterTitle: {
        fontWeight: 'bold',
        marginBottom: 5,
    },
});
