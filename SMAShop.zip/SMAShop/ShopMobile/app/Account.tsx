import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import AccountInfoCard from './AccountInfoCard';

const Account: React.FC<{ setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>> }> = ({ setIsLoggedIn }) => {
    return (
        <View style={styles.container}>
            <View style={styles.headerContainer}>
                <Image
                    style={styles.headerImage}
                    source={{ uri: 'https://www.kultofathena.com/wp-content/uploads/2021/03/weapons_page_title_bar.jpg' }}
                />
                <View style={styles.overlay} />
                <Text style={styles.headerText}>My Account</Text>
            </View>
            <AccountInfoCard setIsLoggedIn={setIsLoggedIn} isAccount={true} />
        </View>
    );
};

export default Account;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    headerContainer: {
        position: 'relative',
        maxHeight: 200,
        overflow: 'hidden',
    },
    headerImage: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
    },
    overlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
    },
    headerText: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -50 }, { translateY: -50 }],
        fontFamily: 'Metamorphous',
        color: '#fff',
        fontSize: 24,
        textAlign: 'center',
    },
});
