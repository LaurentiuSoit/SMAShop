import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
} from 'react-native';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import {BASE_URL} from "@/app/Utils/Utilities";

interface LoginResponse {
    message: string;
    id: number;
}

const SignUpForm: React.FC<{ setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>> }> = ({ setIsLoggedIn }) => {
    const [shopUserCreationDTO, setShopUserCreationDTO] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        password: ''
    });

    const [loginDTO, setLoginDTO] = useState({
        email: '',
        password: ''
    });

    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);
    const [showPassword, setShowPassword] = useState(false);
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    const handleClickShowPassword = () => setShowPassword(!showPassword);

    const handleChangeSignUp = (name: string, value: string) => {
        setShopUserCreationDTO(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleChangeLogIn = (name: string, value: string) => {
        setLoginDTO(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmitSignup = async () => {
        try {
            const response = await fetch(`${BASE_URL}/user/signup`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(shopUserCreationDTO)
            });

            const result = await response.text();
            if (response.ok) {
                setSuccess(result);
                setError(null);
            } else {
                throw new Error('Signup failed.');
            }
        } catch (err: unknown) {
            setError((err as Error).message);
            setSuccess(null);
        }
    };

    const handleSubmitLogin = async () => {
        try {
            const response = await fetch(`${BASE_URL}/user/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(loginDTO)
            });

            const result: LoginResponse = await response.json();
            if (response.ok) {
                setError(null);
                await AsyncStorage.setItem("logged-in", "true");
                await AsyncStorage.setItem("user-id", result.id.toString());
                setIsLoggedIn(true);
            } else {
                throw new Error(result.message);
            }
        } catch (err: unknown) {
            setError((err as Error).message);
        }

        try {
            const response = await fetch(`${BASE_URL}/cart/get/${await AsyncStorage.getItem("user-id")}`);
            const result: { id: number } = await response.json();
            if (response.ok) {
                setError(null);
                await AsyncStorage.setItem("cart-id", result.id.toString());
            } else {
                throw new Error('Cart could not be retrieved.');
            }
        } catch (err: unknown) {
            setError((err as Error).message);
        }
        navigation.navigate('MainPage');
    };

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerText}>My Account</Text>
            </View>
            <View style={styles.formContainer}>
                <Icon name="account-circle" size={80} color="#a30015" style={styles.icon} />
                <Text style={styles.title}>Log In</Text>
                {error && <Text style={styles.errorText}>{error}</Text>}
                <TextInput
                    style={styles.input}
                    placeholder="Email"
                    placeholderTextColor="#999"
                    value={loginDTO.email}
                    onChangeText={(value) => handleChangeLogIn('email', value)}
                    keyboardType="email-address"
                />
                <View style={styles.passwordContainer}>
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor="#999"
                        value={loginDTO.password}
                        onChangeText={(value) => handleChangeLogIn('password', value)}
                        secureTextEntry={!showPassword}
                    />
                    <TouchableOpacity onPress={handleClickShowPassword}>
                        <Icon name={showPassword ? "visibility-off" : "visibility"} size={20} color="white" />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity style={styles.button} onPress={handleSubmitLogin}>
                    <Text style={styles.buttonText}>LOG IN</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
                    <Text style={styles.linkText}>Forgot Password?</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.formContainer}>
                {success && <Text style={styles.successText}>{success}</Text>}
                <Icon name="lock" size={80} color="#a30015" style={styles.icon} />
                <Text style={styles.title}>Sign Up</Text>
                <TextInput
                    style={styles.input}
                    placeholder="First Name"
                    placeholderTextColor="#999"
                    value={shopUserCreationDTO.firstName}
                    onChangeText={(value) => handleChangeSignUp('firstName', value)}
                />
                <TextInput
                    style={styles.input}
                    placeholder="Last Name"
                    placeholderTextColor="#999"
                    value={shopUserCreationDTO.lastName}
                    onChangeText={(value) => handleChangeSignUp('lastName', value)}
                />
                <TextInput
                    style={styles.input}
                    placeholder="Email"
                    placeholderTextColor="#999"
                    value={shopUserCreationDTO.email}
                    onChangeText={(value) => handleChangeSignUp('email', value)}
                    keyboardType="email-address"
                />
                <TextInput
                    style={styles.input}
                    placeholder="Phone Number"
                    placeholderTextColor="#999"
                    value={shopUserCreationDTO.phoneNumber}
                    onChangeText={(value) => handleChangeSignUp('phoneNumber', value)}
                    keyboardType="phone-pad"
                />
                <View style={styles.passwordContainer}>
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor="#999"
                        value={shopUserCreationDTO.password}
                        onChangeText={(value) => handleChangeSignUp('password', value)}
                        secureTextEntry={!showPassword}
                    />
                    <TouchableOpacity onPress={handleClickShowPassword}>
                        <Icon name={showPassword ? "visibility-off" : "visibility"} size={20} color="white" />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity style={styles.button} onPress={handleSubmitSignup}>
                    <Text style={styles.buttonText}>SIGN UP</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

export default SignUpForm;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#1a1a1a',
    },
    header: {
        padding: 20,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#be9359',
    },
    headerText: {
        fontFamily: 'Metamorphous',
        color: 'white',
        fontSize: 24,
        textAlign: 'center',
    },
    formContainer: {
        padding: 20,
        alignItems: 'center',
    },
    icon: {
        marginBottom: 20,
    },
    title: {
        color: 'white',
        fontSize: 20,
        marginBottom: 20,
    },
    input: {
        backgroundColor: '#333333',
        color: 'white',
        width: '100%',
        padding: 10,
        borderRadius: 5,
        marginBottom: 15,
    },
    passwordContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: '100%',
    },
    button: {
        backgroundColor: '#a30015',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 5,
        marginTop: 20,
        width: '100%',
        alignItems: 'center',
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
    },
    linkText: {
        color: 'white',
        marginTop: 15,
    },
    errorText: {
        color: 'red',
        marginBottom: 10,
    },
    successText: {
        color: 'green',
        marginBottom: 10,
    },
});
