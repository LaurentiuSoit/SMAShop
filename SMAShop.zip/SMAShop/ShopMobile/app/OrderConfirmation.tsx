import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const OrderConfirmation: React.FC = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.confirmText}>
                Your order has been placed!
            </Text>
        </View>
    );
};

export default OrderConfirmation;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#1a1a1a',
    },
    confirmText: {
        fontFamily: 'Metamorphous',
        color: 'green',
        fontSize: 24,
        textAlign: 'center',
    },
});
