import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import { ProductListProps } from './Components/Props/ProductListProps';
import { productImage } from './Utils/Utilities';
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";

const ProductList: React.FC<ProductListProps> = ({ products }) => {
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();

    return (
        <ScrollView contentContainerStyle={styles.productContainer}>
            {products.map(product => (
                <View style={styles.card} key={product.id}>
                    <TouchableOpacity
                        style={styles.productLink}
                        onPress={() => {
                            if (product?.id !== undefined) {
                                navigation.navigate('Product', {productId: product.id});
                            } else {
                                console.error("Product ID is undefined");
                            }
                        }}
                    >
                        <Image
                            style={styles.productImage}
                            source={{ uri: productImage(product.name) }}
                            alt="Product Image"
                        />
                        <Text style={styles.productName}>{product.name}</Text>
                    </TouchableOpacity>
                    <Text style={styles.productDescription}>${product.price}{'\n\n'}{product.description}</Text>
                    <Text style={product.availableQuantity > 0 ? styles.inStockText : styles.outOfStockText}>
                        {product.availableQuantity > 0 ? 'In Stock' : 'Out of Stock'}
                    </Text>
                    <TouchableOpacity
                        style={styles.selectOptionsButton}
                        onPress={() => navigation.navigate('Product', { productId: product.id })}
                    >
                        <Text style={styles.buttonText}>View Product</Text>
                    </TouchableOpacity>
                </View>
            ))}
        </ScrollView>
    );
}

export default ProductList;

const styles = StyleSheet.create({
    productContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        maxWidth: 1400,
        justifyContent: 'flex-start',
        paddingHorizontal: 10,
        paddingVertical: 20,
    },
    card: {
        borderWidth: 1,
        borderColor: 'dimgrey',
        maxWidth: 250,
        margin: 15,
        backgroundColor: '#1a1a1a',
        height: 'auto',
        width: 230,
        padding: 10,
    },
    productLink: {
        color: '#e1b65b',
        textDecorationLine: 'none',
        alignItems: 'center',
    },
    productName: {
        color: '#e1b65b',
        fontSize: 18,
        textAlign: 'center',
        marginVertical: 10,
    },
    productDescription: {
        color: '#be9359',
        backgroundColor: '#1a1a1a',
        height: 80,
        fontSize: 14,
        marginBottom: 10,
    },
    inStockText: {
        color: '#77a464',
        fontSize: 16,
        marginBottom: 10,
        textAlign: 'center',
    },
    outOfStockText: {
        color: 'red',
        fontSize: 16,
        marginBottom: 10,
        textAlign: 'center',
    },
    selectOptionsButton: {
        backgroundColor: '#be9359',
        paddingVertical: 10,
        alignItems: 'center',
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 16,
    },
    productImage: {
        height: 200,
        width: '90%',
        alignSelf: 'center',
    },
});
