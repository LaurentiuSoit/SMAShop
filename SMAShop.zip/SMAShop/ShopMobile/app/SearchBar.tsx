import React, { useEffect, useState } from 'react';
import { View, TextInput, StyleSheet, Keyboard } from 'react-native';
import {NavigationProp, useNavigation, useRoute} from '@react-navigation/native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {useFocusEffect} from "expo-router";
import {RootStackParamList} from "@/app/Components/Props/RootStackParamList";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

const SearchBar: React.FC = () => {
    const [searchString, setSearchString] = useState<string>("");
    const navigation = useNavigation<NavigationProp<RootStackParamList>>();
    const route = useRoute();

    const handleChange = (value: string) => {
        setSearchString(value);
    };

    const handleSearch = () => {
        navigation.navigate('SearchPage', { searchString });
    };

    useFocusEffect(
        React.useCallback(() => {
            // Reset the search string whenever the screen is focused
            setSearchString("");
        }, [route])
    );

    return (
        <View style={styles.searchContainer}>
            <TextInput
                style={styles.searchBar}
                placeholder="Search for products..."
                placeholderTextColor="grey"
                value={searchString}
                onChangeText={handleChange}
                onSubmitEditing={handleSearch}
                returnKeyType="search"
            />
            <TouchableOpacity style={styles.iconButton} onPress={handleSearch}>
                <MaterialIcons name="search" size={24} color="#766145" />
            </TouchableOpacity>
        </View>
    );
};

export default SearchBar;

const styles = StyleSheet.create({
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#333333',
        borderRadius: 30,
        paddingHorizontal: 10,
    },
    searchBar: {
        flex: 1,
        height: 40,
        color: 'white',
        paddingVertical: 8,
    },
    iconButton: {
        paddingHorizontal: 5,
    },
});
