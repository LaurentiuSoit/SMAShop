-- Populate category table
INSERT INTO category (category_name, category_description)
VALUES 
    ('Swords', 'European Swords, Asian Swords, Middle Eastern Swords, Indian Swords, US Civil War Swords, Modern Tactical Swords, Fantasy Swords'),
    ('Weapons', 'Daggers, Axes, Maces, War Hammers, Spears, Polearms, Archery, Other weapons'),
    ('Armor', 'Helmets, Plate Armor, Padded Armor, Brigandine Armor, Leather Armor, Samurai Armor, Chainmail Armor, Accessories'),
    ('Shields', 'Greek Shields, Roman Shields, Scottish Targes, Viking & Norman Shields, Medieval Shields, Bucklers & Small Shields'),
    ('Clothing', 'Belts, Gambesons, Tunics, Pants, Coats, Dublets, Vests, Hats, GLoves, Footwear, Shirts'),
    ('LARP Weapons & Gear', 'Foam LARP Swords, Shields, Knives, Axes, Maces Maintenance Kits, Spears, Masks, Makeup, Prosthetics, Props');

INSERT INTO product (product_name, product_description, price, available_quantity, added_date, category_id)
VALUES
    ('Mace', 'Mace', 100, 76, '2024-08-09', 2),
    ('Halberd', 'Halberd', 300, 43, '2024-08-09', 2),
    ('Katana', 'Katana', 175, 30, '2024-08-09', 1),
    ('Longsword', 'Longsword', 200, 65, '2024-08-09', 1);

-- Populate product_attribute table
INSERT INTO product_attribute (product_attribute_name)
VALUES 
    ('Weight'),
    ('Overall Length'),
    ('Handle Material'),
    ('Blade Length'),
    ('Primary Material'),
    ('Edge'),
    ('Culture'),
    ('Manufacturer');


-- Populate attribute_value table
INSERT INTO attribute_value (val, product_attribute_id)
VALUES 
    ('1.5KG',1),
    ('130CM',2),
    ('Leather',3),
    ('97CM',4),
    ('High Carbon Steel',5),
    ('Sharp',6),
    ('Irish',7),
    ('Japanese',7),
    ('Balaur Arms',8);

INSERT INTO valid_attribute(product_attribute_id, product_id)
VALUES
    (1, 1),
    (2, 1),
    (5, 1);

INSERT INTO valid_attribute_value(attribute_value_id, valid_attribute_id)
VALUES
    (1, 1),
    (2, 2),
    (5, 3);