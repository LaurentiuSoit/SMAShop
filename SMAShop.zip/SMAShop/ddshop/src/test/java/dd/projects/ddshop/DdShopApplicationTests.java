package dd.projects.ddshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
