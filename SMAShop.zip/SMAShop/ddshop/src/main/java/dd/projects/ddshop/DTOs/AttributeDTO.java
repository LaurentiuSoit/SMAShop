package dd.projects.ddshop.DTOs;

import lombok.Data;

@Data
public class AttributeDTO {

    private String name;
    private String value;
}
