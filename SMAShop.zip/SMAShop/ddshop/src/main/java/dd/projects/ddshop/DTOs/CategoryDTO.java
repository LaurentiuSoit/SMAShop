package dd.projects.ddshop.DTOs;

import lombok.Data;

@Data
public class CategoryDTO {

    private Integer id;
    private String name;
    private String description;
}
