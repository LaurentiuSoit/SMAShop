package dd.projects.ddshop.DTOs;

import lombok.Data;

@Data
public class ValidAttributeDTO {

    private Integer id;
    private Integer productAttributeId;
    private Integer attributeValueId;
}
