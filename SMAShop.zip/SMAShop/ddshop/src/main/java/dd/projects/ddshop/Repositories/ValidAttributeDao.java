package dd.projects.ddshop.Repositories;

import dd.projects.ddshop.Entities.ValidAttribute;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ValidAttributeDao extends JpaRepository<ValidAttribute, Integer> {}
