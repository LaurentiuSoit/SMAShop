-- Create tables
CREATE TABLE IF NOT EXISTS product_attribute (
    id SERIAL PRIMARY KEY,
    product_attribute_name VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS category (
    id SERIAL PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL,
    category_description VARCHAR(300) NOT NULL
);

CREATE TABLE IF NOT EXISTS address (
    id SERIAL PRIMARY KEY,
    street_line VARCHAR(50) NOT NULL,
    postal_code INT NOT NULL,
    city VARCHAR(50) NOT NULL,
    county VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL
);


CREATE TABLE IF NOT EXISTS product (
    id SERIAL PRIMARY KEY,
    product_name VARCHAR(50) NOT NULL,
    product_description VARCHAR(150) NOT NULL,
    price INT NOT NULL,
    available_quantity INT NOT NULL,
    added_date DATE NOT NULL,
    category_id INT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES category(id)
);

CREATE TABLE IF NOT EXISTS valid_attribute (
    id SERIAL PRIMARY KEY,
    product_attribute_id INT NOT NULL,
    FOREIGN KEY (product_attribute_id) REFERENCES product_attribute(id),
    product_id INT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES product(id)
);

CREATE TABLE IF NOT EXISTS attribute_value (
    id SERIAL PRIMARY KEY,
    val VARCHAR(50) NOT NULL,
    product_attribute_id INT NOT NULL,
    FOREIGN KEY (product_attribute_id) REFERENCES product_attribute(id)
);

CREATE TABLE IF NOT EXISTS valid_attribute_value (
    id SERIAL PRIMARY KEY,
    attribute_value_id INT NOT NULL,
    FOREIGN KEY (attribute_value_id) REFERENCES attribute_value(id),
    valid_attribute_id INT NOT NULL,
    FOREIGN KEY (valid_attribute_id) REFERENCES valid_attribute(id)
);

CREATE TABLE IF NOT EXISTS shop_user (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(50),
    phone_number VARCHAR(15),
    password VARCHAR(50),
    default_delivery_address INT,
    FOREIGN KEY (default_delivery_address) REFERENCES address(id),
    default_billing_address INT,
    FOREIGN KEY (default_billing_address) REFERENCES address(id)
);

CREATE TABLE IF NOT EXISTS cart (
    id SERIAL PRIMARY KEY,
    shop_user_id INT NOT NULL,
    FOREIGN KEY (shop_user_id) REFERENCES shop_user(id),
    total_price INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cart_entry (
    id SERIAL PRIMARY KEY,
    product_id INT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES product(id),
    quantity INT NOT NULL,
    price_per_piece INT NOT NULL,
    total_price_per_entry INT NOT NULL,
    cart_id INT NOT NULL,
    FOREIGN KEY (cart_id) REFERENCES cart(id)
);

-- Create enum type for paymentType
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'paymenttype') THEN
        CREATE TYPE paymentType AS ENUM ('Credit Card', 'Debit Card', 'PayPal', 'GooglePay', 'Bank Transfer');
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS shop_order (
    id SERIAL PRIMARY KEY,
    shop_user_id INT NOT NULL,
    FOREIGN KEY (shop_user_id) REFERENCES shop_user(id),
    cart_id INT NOT NULL,
    FOREIGN KEY (cart_id) REFERENCES cart(id),
    payment_type paymentType NOT NULL,
    delivery_address INT NOT NULL,
    FOREIGN KEY (delivery_address) REFERENCES address(id),
    invoice_address INT NOT NULL,
    FOREIGN KEY (invoice_address) REFERENCES address(id),
    total_price INT NOT NULL,
    order_date DATE NOT NULL
);
